#include "kernel.h"
#include "globals.h"
#include "types.h"
#include "errno.h"

#include "util/string.h"
#include "util/printf.h"
#include "util/debug.h"

#include "fs/dirent.h"
#include "fs/fcntl.h"
#include "fs/stat.h"
#include "fs/vfs.h"
#include "fs/vnode.h"
#include "mm/kmalloc.h"

/* This takes a base 'dir', a 'name', its 'len', and a result vnode.
 * Most of the work should be done by the vnode's implementation
 * specific lookup() function, but you may want to special case
 * "." and/or ".." here depnding on your implementation.
 *
 * If dir has no lookup(), return -ENOTDIR.
 *
 * Note: returns with the vnode refcount on *result incremented.
 */
int
lookup(vnode_t *dir, const char *name, size_t len, vnode_t **result)		/* done */
{
      KASSERT(NULL != dir);
      
      if(dir->vn_ops->lookup ==NULL)
      return -ENOTDIR;
      int error = 0;
      error = dir->vn_ops->lookup(dir,name,len,result);
      KASSERT(NULL != name);
      KASSERT(NULL != result);
      return error;
}


/* When successful this function returns data in the following "out"-arguments:
 *  o res_vnode: the vnode of the parent directory of "name"
 *  o name: the `basename' (the element of the pathname)
 *  o namelen: the length of the basename
 *
 * For example: dir_namev("/s5fs/bin/ls", &namelen, &name, NULL,
 * &res_vnode) would put 2 in namelen, "ls" in name, and a pointer to the
 * vnode corresponding to "/s5fs/bin" in res_vnode.
 *
 * The "base" argument defines where we start resolving the path from:
 * A base value of NULL means to use the process's current working directory,
 * curproc->p_cwd.  If pathname[0] == '/', ignore base and start with
 * vfs_root_vn.  dir_namev() should call lookup() to take care of resolving each
 * piece of the pathname.
 *
 * Note: A successful call to this causes vnode refcount on *res_vnode to
 * be incremented.
 */
int
dir_namev(const char *pathname, size_t *namelen, const char **name,	/* done */
          vnode_t *base, vnode_t **res_vnode)
{         
       if(strlen(pathname) == 0) 
		return -ENOENT;

	char *str = (char *) kmalloc(strlen(pathname));
	char *start_ptr = NULL, *tab_ptr = NULL;
	strcpy(str,pathname);
	vnode_t *trial = NULL;
	*res_vnode = NULL;

	if (pathname[0] == '/')  
	{
		trial = vfs_root_vn;
	}
	else if (base != NULL)
	{
		trial = base;
	}
	else
	{
		trial = curproc->p_cwd;
	}

	if (pathname[0] == '/')
	{
		start_ptr = &str[1];
		tab_ptr = &str[1];
	}
	else    
	{
		start_ptr = &str[0];
		tab_ptr = &str[0];         
	} 

	int len = strlen(start_ptr);
	int flag = 0;
	start_ptr = strchr(start_ptr,'\0');

	while(start_ptr != tab_ptr)
	{
		if(*start_ptr == '/')
		{
			flag = 1;
			*start_ptr = '\0';
			*name = ++start_ptr;
			*namelen = strlen(*name);
			break;
		}
		start_ptr--;
	}
	if(flag == 0)
	{
		*name = tab_ptr;
		*namelen = strlen(*name);
	}

	start_ptr = tab_ptr;

        while (tab_ptr != NULL && flag == 1)
        {            	
		start_ptr = tab_ptr;
		tab_ptr = strchr(start_ptr, '/');
		if (tab_ptr != NULL) 
		{
			*tab_ptr++ = '\0';
		}
		if(*res_vnode != NULL) 
			vput(*res_vnode);
		
		int error = lookup(trial,start_ptr,strlen(start_ptr),res_vnode);

		if (error < 0)            
		{
			return error;                                                     
		}
		trial = *res_vnode;	
        }
        

	if(*res_vnode == NULL)
	{
		if(pathname[0] == '/')
		{
			*res_vnode = vfs_root_vn;	
		}
		else if (base != NULL)
		{
			*res_vnode = base;
		}
		else
		{
			*res_vnode = curproc->p_cwd;
		}
		vref(*res_vnode);
	}
        return 0;        
}

/* This returns in res_vnode the vnode requested by the other parameters.
 * It makes use of dir_namev and lookup to find the specified vnode (if it
 * exists).  flag is right out of the parameters to open(2); see
 * <weenix/fnctl.h>.  If the O_CREAT flag is specified, and the file does
 * not exist call create() in the parent directory vnode.
 *
 * Note: Increments vnode refcount on *res_vnode.
 */
int
open_namev(const char *pathname, int flag, vnode_t **res_vnode, vnode_t *base) /* done */
{
	       size_t namelen = 0;
       const char *name = (char *) kmalloc(NAME_LEN);
       vnode_t *res_par_vnode = NULL;



     int error = 0;
     if ( (error = dir_namev(pathname,&namelen,&name,base,&res_par_vnode)) < 0)
        return error;
	

        
     if ( (error = lookup(res_par_vnode,name,namelen,res_vnode)) < 0)
     {
        if (( (flag & O_CREAT) == O_CREAT) && error == -ENOENT)
        {
              /*if (res_vnode == NULL && (flag &amp O_CREAT))*/
              KASSERT(NULL != res_par_vnode->vn_ops->create);  
		int error1 = 0;           
             error1 = res_par_vnode->vn_ops->create(res_par_vnode,name,namelen,res_vnode);     
		if(error1 < 0)
		{
			if(*res_vnode)
				vput(*res_vnode);		
			if(res_par_vnode)
				vput(res_par_vnode);	
			
			return error1;
		}
        }
	else 
	{	
		if(*res_vnode)
			vput(*res_vnode);		
		if(res_par_vnode)
			vput(res_par_vnode);	
		return error;
	}
		
             
     }
	if(res_par_vnode)
		vput(res_par_vnode);	
     
     return 0;  
}

#ifdef __GETCWD__
/* Finds the name of 'entry' in the directory 'dir'. The name is writen
 * to the given buffer. On success 0 is returned. If 'dir' does not
 * contain 'entry' then -ENOENT is returned. If the given buffer cannot
 * hold the result then it is filled with as many characters as possible
 * and a null terminator, -ERANGE is returned.
 *
 * Files can be uniquely identified within a file system by their
 * inode numbers. */
int
lookup_name(vnode_t *dir, vnode_t *entry, char *buf, size_t size)
{
        NOT_YET_IMPLEMENTED("GETCWD: lookup_name");
        return -ENOENT;
}


/* Used to find the absolute path of the directory 'dir'. Since
 * directories cannot have more than one link there is always
 * a unique solution. The path is writen to the given buffer.
 * On success 0 is returned. On error this function returns a
 * negative error code. See the man page for getcwd(3) for
 * possible errors. Even if an error code is returned the buffer
 * will be filled with a valid string which has some partial
 * information about the wanted path. */
ssize_t
lookup_dirpath(vnode_t *dir, char *buf, size_t osize)
{
        NOT_YET_IMPLEMENTED("GETCWD: lookup_dirpath");

        return -ENOENT;
}
#endif /* __GETCWD__ */
