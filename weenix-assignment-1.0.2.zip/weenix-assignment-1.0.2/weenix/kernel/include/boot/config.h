#pragma once

#define KERNEL_PHYS_BASE 0x100000
#define MEMORY_MAP_BASE 0x9000
