/* entry.h */

void kmain(void);
