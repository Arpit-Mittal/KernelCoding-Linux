#pragma once

int do_brk(void *addr, void **ret);
