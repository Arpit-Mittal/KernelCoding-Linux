#pragma once

struct mmobj;

void anon_init();
struct mmobj *anon_create(void);

extern int anon_count;

