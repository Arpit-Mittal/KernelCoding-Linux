#pragma once

/**
 * Initializes the memdevs subsystem.
 */
void memdevs_init(void);
