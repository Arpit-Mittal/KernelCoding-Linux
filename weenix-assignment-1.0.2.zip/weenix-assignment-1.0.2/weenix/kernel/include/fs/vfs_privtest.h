
#pragma once

void vfs_privtest(void);
