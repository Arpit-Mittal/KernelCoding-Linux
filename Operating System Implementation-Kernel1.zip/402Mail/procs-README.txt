Kernel Assignment - 1
=====================

Group Members:
++++++++++++++

Arpit Mittal, DineshKumar Patel, Pankaj Kumar

Submitted Files:
++++++++++++++++

kmain.c, kthread.c, kmutex.c, proc.c, sched.c, config.mk, procs-README.txt


Test Cases:
+++++++++++

For checking the various test cases, the tester should comment/ uncomment the test case as well as global variables assigned for that specific test case carefully. It is, because, all the test cases have been put and uncommented in the kmain.c. Only one test case (and its corresponding global variables) will be uncommented at a given time. In our submitted assignment, we have left "Test Case 1" as uncommented.Test case 1 will run as it is (by typing command sequence of make clean,make, ./weenix -n)as it is left uncommented. So, to run "Test Case 2" after testing "Test Case 1", comment out "Test Case 1" and its associated global variables. And, uncomment "Test Case 2" and its associated global variables. 

In order to check our implementation of Kernel Assignment 1, we ran several Test Cases, which are as follows:

------------------------------------------------Test Case-1----------------------------------------

In this elementary test case, we created two processes, "process3" and "process4" as follows:

INIT process--->process3
	    --->process4

And, these two processes accessed a global variable, called "count" and incremented it.

------------------------------------------------Test Case-2----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->process3--->process4
			--->process5

Now, we put the process4 on "cancellable sleep on" mode by calling "sched_cancellable_sleep_on(queue)".
It is process5, which is cancelling the sleep mode of process4, by calling "sched_cancel(thread_of_process4)".

This can be verified by the following order of gdb statement:

1. Inside process id: 4, value of count(after increment): <value of count>
(After this statement, we are putting process4 on "cancellable sleep on" mode).
2. Inside process id: 5, value of count(after increment): <value of count>
(Now, in Process 5, we are cancelling the sleep mode of process4).
3. Inside process id: 5, value of count(after cancelling Thread4): <value of count>
(Context, now swtiches to Process 4, because the sleep has been cancelled up by process 5).
4. Inside process id: 4, value of count(after the cancellable sleep): <value of count>

------------------------------------------------Test Case-3----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->process3--->process4
			--->process5
			--->process6

Now, here are killing all processes, by calling proc_kill_all() in process4.
This can be verified the panic statement in the function of process4.

------------------------------------------------Test Case-4----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->process3--->process4--->process5
				    --->process6
				    --->process7

Now, we are termintating the process4 by calling kthread_exit(). 
This will reparent the processes process5, process6 and process7 to the INIT process (PID = 1).

That is, the new hierarchy will be as follows:

INIT process--->process3
	    --->process5
	    --->process6
	    --->process7

This can be verified by the gdb statements in the test case.

------------------------------------------------Test Case-5----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->process3
            --->process4
	    --->process5

Here, in process3, we are locking a mutex and updating a global variable, say count.
Now, this process will go in "sleep" mode by calling "sched_sleep_on(common_queue)" (It still owns the mutex).

As, process4 is, now in runnable queue, it will start executing. Here, we are trying to lock the same mutex, held by process3.
But, it will not be able to own it. Therefore, process4 will be added to the mutex waiting queue. And, process5 will start executing.

Process5, will now simply wake up the "sleeping" process3, by calling "sched_wakeup_on(common_queue)". 
This will add process3 in the runnable queue. The rest part of process3 will execute, which will later on release the mutex and make the process4 runnable.

The rest part of process4 will execute.

The whole process can be observed by gdb statements.

------------------------------------------------Test Case-6----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->process3
            --->process4

For this test case, we have used two mutex variables, mutex1 and mutex2.

First of all, process3 will acquire the mutex: mutex1 and process4 will acquire mutex: mutex2.
Now, they will try to own each other's owned mutex, i.e. process3 will try to lock mutex2 and process4 will try to lock mutex1.

Thus, deadlock is acheived.
This can be verified by the gdb and panic statements in the functions of process3 and process4.

------------------------------------------------Test Case-7----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->producer
            --->consumer

Here, we have defined a buffer of size 5. 
Now, the producer will try to update the buffer for 7 times. 
As the buffer size is 5 only; after 5 updates, it will sleep on by calling "sched_sleep_on(common_queue)".
But, before going to sleep, it will wake up the "consumer" from the common queue by calling "sched_wakeup_on(common_queue)".

The same process is replicated for the Consumer as well.

The whole "Producer-Consumer Problem" solution can be observed by the gdb statements for this test case.

------------------------------------------------Test Case-8----------------------------------------

In this test case, we created the following process hierarchy:

INIT process--->process3--->process5--->process9
				    --->process10
			--->process6
            --->process4--->process7
			--->process8

Here, all the threads of the processes (except process7) have been terminated by calling "do_waitpid()".
For, the thread of process7, we have used "kthread_exit()".

This scenario can be observed by subsequent gdb and panic statements in the test case.



