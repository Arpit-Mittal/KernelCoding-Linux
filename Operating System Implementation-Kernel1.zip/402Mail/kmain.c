#include "types.h"
#include "globals.h"
#include "kernel.h"

#include "util/gdb.h"
#include "util/init.h"
#include "util/debug.h"
#include "util/string.h"
#include "util/printf.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/pagetable.h"
#include "mm/pframe.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "main/acpi.h"
#include "main/apic.h"
#include "main/interrupt.h"
#include "main/cpuid.h"
#include "main/gdt.h"

#include "proc/sched.h"
#include "proc/proc.h"
#include "proc/kthread.h"

#include "drivers/dev.h"
#include "drivers/blockdev.h"
#include "drivers/tty/virtterm.h"

#include "api/exec.h"
#include "api/syscall.h"

#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/fcntl.h"
#include "fs/stat.h"

#include "test/kshell/kshell.h"

#include "mm/kmalloc.h"
#include "proc/kmutex.h"

GDB_DEFINE_HOOK(boot)
GDB_DEFINE_HOOK(initialized)
GDB_DEFINE_HOOK(shutdown)

static void      *bootstrap(int arg1, void *arg2);
static void      *idleproc_run(int arg1, void *arg2);
static kthread_t *initproc_create(void);
static void      *initproc_run(int arg1, void *arg2);
static void       hard_shutdown(void);
static context_t bootstrap_context;

int count;
static void * process3_routine(int arg1, void *arg2);
static void * process4_routine(int arg1, void *arg2); 

/*========== variables for test case 2 =========*/
/*
ktqueue_t cancellable_q;
kthread_t *thread4;
static void * process5_routine(int arg1, void *arg2);
*/


/*========== variables for test case 3 =========*/
/*
static void * process5_routine(int arg1, void *arg2);
static void * process6_routine(int arg1, void *arg2);
*/

/*========== variables for test case 4 =========*/
/*
static void * process5_routine(int arg1, void *arg2);
static void * process6_routine(int arg1, void *arg2);
static void * process7_routine(int arg1, void *arg2);    
*/
/*========== variables for test case 5 =========*/
/*
static void * process5_routine(int arg1, void *arg2);
static kmutex_t *mutex;
static ktqueue_t commonq;
proc_t *process3;
proc_t *process4;
proc_t *process5;
*/

/*========== variables for test case 6 =========*/
/*
static kmutex_t *mutex1;
static kmutex_t *mutex2;
proc_t *process3;
proc_t *process4;   

*/
/*========== variables for test case 7 =========*/
/*
proc_t *producer;
proc_t *consumer; 
int a[5] = {0};
int empty = 5;
int occupied = 0;
int nextin = 0, nextout = 0;
ktqueue_t pro_con_q;
static void * producer_routine(int arg1, void *arg2);
static void * consumer_routine(int arg1, void *arg2);  
*/

/*========== variables for test case 8 =========*/
/*
static void *process5_routine(int arg1, void *arg2);
static void *process6_routine(int arg1, void *arg2);
static void *process7_routine(int arg1, void *arg2);
static void *process8_routine(int arg1, void *arg2);
static void *process9_routine(int arg1, void *arg2);
static void *process10_routine(int arg1, void *arg2);
*/

/**
 * This is the first real C function ever called. It performs a lot of
 * hardware-specific initialization, then creates a pseudo-context to
 * execute the bootstrap function in.
 */
void
kmain()
{
        GDB_CALL_HOOK(boot);
       
        dbg_init();
        dbgq(DBG_CORE, "Kernel binary:\n");
        dbgq(DBG_CORE, "  text: 0x%p-0x%p\n", &kernel_start_text, &kernel_end_text);
        dbgq(DBG_CORE, "  data: 0x%p-0x%p\n", &kernel_start_data, &kernel_end_data);
        dbgq(DBG_CORE, "  bss:  0x%p-0x%p\n", &kernel_start_bss, &kernel_end_bss);

        page_init();

	dbg(DBG_SCHED, " inside kmain");

        pt_init();
        slab_init();
        pframe_init();

        acpi_init();
        apic_init();
        intr_init();

        gdt_init();

        /* initialize slab allocators */
#ifdef __VM__
        anon_init();
        shadow_init();
#endif
        vmmap_init();
        proc_init();
        kthread_init();

#ifdef __DRIVERS__
        bytedev_init();
        blockdev_init();
#endif

        void *bstack = page_alloc();
        pagedir_t *bpdir = pt_get();
        KASSERT(NULL != bstack && "Ran out of memory while booting.");

        context_setup(&bootstrap_context, bootstrap, 0, NULL, bstack, PAGE_SIZE, bpdir);

        context_make_active(&bootstrap_context);
        panic("\nReturned to kmain()!!!\n");
}

/**
 * This function is called from kmain, however it is not running in a
 * thread context yet. It should create the idle process which will
 * start executing idleproc_run() in a real thread context.  To start
 * executing in the new process's context call context_make_active(),
 * passing in the appropriate context. This function should _NOT_
 * return.
 *
 * Note: Don't forget to set curproc and curthr appropriately.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
bootstrap(int arg1, void *arg2)
{
	/* necessary to finalize page table information */
        pt_template_init();

        /*NOT_YET_IMPLEMENTED("PROCS: bootstrap");*/
        proc_t *idle_proc = proc_create("idle"); /*creating idle process */
        kthread_t *thread = kthread_create(idle_proc, idleproc_run, arg1, arg2);
	curproc = idle_proc;
	KASSERT(NULL != curproc && "\nIdle Process has not been created successfully\n");
	KASSERT(PID_IDLE == curproc->p_pid && "\nThe created Process is not Idle process\n");
        curthr = thread; 
        KASSERT(NULL != curthr && "\nThe thread for the IDLE process has not been created successfully\n");
        context_make_active(&thread->kt_ctx);
        
	panic("weenix returned to bootstrap()!!! BAD!!!\n"); 
      
        return NULL;
}

/**
 * Once we're inside of idleproc_run(), we are executing in the context of the
 * first process-- a real context, so we can finally begin running
 * meaningful code.
 *
 * This is the body of process 0. It should initialize all that we didn't
 * already initialize in kmain(), launch the init process (initproc_run),
 * wait for the init process to exit, then halt the machine.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
idleproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child;

        /* create init proc */
        kthread_t *initthr = initproc_create();

        init_call_all();
        GDB_CALL_HOOK(initialized);

        /* Create other kernel threads (in order) */

#ifdef __VFS__
        /* Once you have VFS remember to set the current working directory
         * of the idle and init processes */

        /* Here you need to make the null, zero, and tty devices using mknod */
        /* You can't do this until you have VFS, check the include/drivers/dev.h
         * file for macros with the device ID's you will need to pass to mknod */
#endif

        /* Finally, enable interrupts (we want to make sure interrupts
         * are enabled AFTER all drivers are initialized) */
        intr_enable();

        /* Run initproc */
        sched_make_runnable(initthr);
        /* Now wait for it */
        child = do_waitpid(-1, 0, &status);
        KASSERT(PID_INIT == child);

#ifdef __MTP__
        kthread_reapd_shutdown();
#endif


#ifdef __VFS__
        /* Shutdown the vfs: */
        dbg_print("weenix: vfs shutdown...\n");
        vput(curproc->p_cwd);
        if (vfs_shutdown())
                panic("vfs shutdown FAILED!!\n");

#endif

        /* Shutdown the pframe system */
#ifdef __S5FS__
        pframe_shutdown();
#endif

        dbg_print("\nweenix: halted cleanly!\n");
        GDB_CALL_HOOK(shutdown);
        hard_shutdown();
        return NULL;
}

/**
 * This function, called by the idle process (within 'idleproc_run'), creates the
 * process commonly refered to as the "init" process, which should have PID 1.
 *
 * The init process should contain a thread which begins execution in
 * initproc_run().
 *
 * @return a pointer to a newly created thread which will execute
 * initproc_run when it begins executing
 */
static kthread_t *
initproc_create(void)
{
        /*NOT_YET_IMPLEMENTED("PROCS: initproc_create"); */
         proc_t *init_proc = proc_create("init"); /*creating idle process*/
	 KASSERT(NULL != init_proc && "\nThe INIT process has not been created successfully\n");
         KASSERT(PID_INIT ==  init_proc->p_pid && "\nPID of INIT process is not 1\n");
         kthread_t *init_thread = kthread_create(init_proc, initproc_run, NULL, NULL);
         KASSERT(init_thread != NULL && "\nThe thread for the INIT process has not been created successfully\n");
         return init_thread;
}

/**
 * The init thread's function changes depending on how far along your Weenix is
 * developed. Before VM/FI, you'll probably just want to have this run whatever
 * tests you've written (possibly in a new process). After VM/FI, you'll just
 * exec "/bin/init".
 *
 * Both arguments are unused.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */

/*===============================================TEST CASE 1=============================================*/

static void *
initproc_run(int arg1, void *arg2)
{	
	proc_t *process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	

	proc_t *process4 = proc_create("process4");
	kthread_t *thread4 = kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);	
	
	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Inside process id: %d, final value of count: %d\n",curproc->p_pid, count);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}

static void *
process3_routine(int arg1, void *arg2)
{
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	return NULL;
}

static void *

process4_routine(int arg1, void *arg2)

{
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	return NULL;
}      


/*===============================================TEST CASE 2=============================================*/
/*
static void *
initproc_run(int arg1, void *arg2)
{
	proc_t *process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	
	

	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}


static void *
process3_routine(int arg1, void *arg2)
{
	
	proc_t *process4 = proc_create("process4");
	thread4= kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);	

	proc_t *process5 = proc_create("process5");
	kthread_t *thread5 = kthread_create(process5, process5_routine, 0, (void *)0);
	sched_make_runnable(thread5);	
	
	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}		
	
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	return NULL;
}         

static void *
process4_routine(int arg1, void *arg2)
{
	count++;
	
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	sched_queue_init(&cancellable_q);
	sched_cancellable_sleep_on(&cancellable_q);
	
	count += 2;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after the cancellable sleep): %d\n",curproc->p_pid, count);
	return NULL;
}

static void *
process5_routine(int arg1, void *arg2)
{
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	sched_cancel(thread4);
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after cancelling Thread3): %d\n",curproc->p_pid, count);
	return NULL;
}    
*/

/*===============================================TEST CASE 3=============================================*/
/*
static void *
initproc_run(int arg1, void *arg2)
{
	proc_t *process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	
	

	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}


static void *
process3_routine(int arg1, void *arg2)
{
	
	proc_t *process4 = proc_create("process4");
	kthread_t *thread4= kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);	

	proc_t *process5 = proc_create("process5");
	kthread_t *thread5 = kthread_create(process5, process5_routine, 0, (void *)0);
	sched_make_runnable(thread5);	
	
	proc_t *process6 = proc_create("process6");
	kthread_t *thread6 = kthread_create(process6, process6_routine, 0, (void *)0);
	sched_make_runnable(thread6);	
	
	
	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}		
	
	return NULL;
}         

static void *
process4_routine(int arg1, void *arg2)
{
	count++;
	
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	count += 2;
	proc_kill_all();
	panic("Error :Control should not here; Prockillall is not verified");
	return NULL;	
}

static void *
process5_routine(int arg1, void *arg2)
{
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after cancelling Thread3): %d\n",curproc->p_pid, count);
	return NULL;
}

static void *
process6_routine(int arg1, void *arg2)
{
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after increment): %d\n",curproc->p_pid, count);
	count++;
	dbg(DBG_INIT, "Inside process id: %d, value of count(after cancelling Thread3): %d\n",curproc->p_pid, count);

	return NULL;
}

*/

/*===============================================TEST CASE 4=============================================*/
    
/*
static void *
initproc_run(int arg1, void *arg2)
{	
	
	proc_t *process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	
	

	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}

static void *
process3_routine(int arg1, void *arg2)
{
	proc_t *process4 = proc_create("process4");
	kthread_t *thread4 = kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);	
	
	pid_t child;
	int status;

	while(!list_empty(&curproc->p_children))

	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}


static void *
process4_routine(int arg1, void *arg2)
{
	
	proc_t *process5 = proc_create("process5");
	kthread_t *thread5= kthread_create(process5, process5_routine, 0, (void *)0);
	sched_make_runnable(thread5);	

	proc_t *process6 = proc_create("process6");
	kthread_t *thread6 = kthread_create(process6, process6_routine, 0, (void *)0);
	sched_make_runnable(thread6);	
	
	proc_t *process7 = proc_create("process7");
	kthread_t *thread7 = kthread_create(process7, process7_routine, 0, (void *)0);
	sched_make_runnable(thread7);	
	dbg(DBG_INIT,"The parent of the Process %d is Process %d\n",process5->p_pid,process5->p_pproc->p_pid);	
	dbg(DBG_INIT,"The parent of the Process %d is Process %d\n",process6->p_pid,process6->p_pproc->p_pid);
	dbg(DBG_INIT,"The parent of the Process %d is Process %d\n",process7->p_pid,process7->p_pproc->p_pid);	
	

	dbg(DBG_INIT,"Process %d is exiting....\n",curproc->p_pid);	
	kthread_exit((void *)1);
	
	pid_t child;
	int status;
	

	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}		
	
	return NULL;
}         

static void *
process5_routine(int arg1, void *arg2)
{
	
	dbg(DBG_INIT,"The new parent of the Process %d is Process %d\n",curproc->p_pid,curproc->p_pproc->p_pid);
	return NULL;	
}

static void *
process6_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"The new parent of the Process %d is Process %d\n",curproc->p_pid,curproc->p_pproc->p_pid);
	return NULL;
}

static void *
process7_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"The new parent of the Process %d is Process %d\n",curproc->p_pid,curproc->p_pproc->p_pid);
	return NULL;
}   
*/
/*===============================================TEST CASE 5=============================================*/
/*

static void *
initproc_run(int arg1, void *arg2)
{
		
	process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	

	process4 = proc_create("process4");
	kthread_t *thread4 = kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);	

	process5 = proc_create("process5");
	kthread_t *thread5= kthread_create(process5, process5_routine, 0, (void *)0);
	sched_make_runnable(thread5);	

	pid_t child;
	int status;
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	return NULL;	
}

static void *
process3_routine(int arg1, void *arg2)
{
	
	mutex=(kmutex_t *)kmalloc(sizeof(kmutex_t));
	
	
	sched_queue_init(&commonq);

	kmutex_init(mutex);	
	dbg(DBG_INIT,"\nIn Process %d is trying to acquire the mutex lock...\n",process3->p_pid);	
	kmutex_lock(mutex);
	dbg(DBG_INIT,"\nIn Process %d is has acquired the mutex lock...\n",process3->p_pid);	
	count += 10;
	dbg(DBG_INIT,"In Process %d the count is incremented to %d after locking mutex\n",process3->p_pid,count);	
	sched_sleep_on(&commonq);
	
	count += 10;
	dbg(DBG_INIT,"In Process %d the count is incremented to %d after returning\n",process3->p_pid,count);	
	kmutex_unlock(mutex);
	dbg(DBG_INIT,"\nIn Process %d is has released the mutex lock...\n",process3->p_pid);	
	return NULL;	
}


static void *
process4_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"\nIn Process %d is trying to acquire the mutex lock...\n",process4->p_pid);	
	kmutex_lock(mutex);	
	dbg(DBG_INIT,"\nIn Process %d is has acquired the mutex lock...\n",process4->p_pid);	
	count += 10;
	dbg(DBG_INIT,"In Process %d the count is incremented to %d after returning\n",process4->p_pid,count);	
	
	kmutex_unlock(mutex);
	dbg(DBG_INIT,"\nIn Process %d is has released the mutex lock...\n",process4->p_pid);	
	return NULL;
}         

static void *
process5_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"\nIn Process %d is waking up the thread in the common queue\n",process5->p_pid);	
	(void)sched_wakeup_on(&commonq);
	return NULL;	
}

*/
/*===============================================TEST CASE 6=============================================*/
/*
static void *
initproc_run(int arg1, void *arg2)
{
		
	process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	

	process4 = proc_create("process4");
	kthread_t *thread4 = kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);	

	mutex1=(kmutex_t *)kmalloc(sizeof(kmutex_t));
	mutex2=(kmutex_t *)kmalloc(sizeof(kmutex_t));	
	kmutex_init(mutex1);
	kmutex_init(mutex2);
	pid_t child;
	int status;
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	return NULL;	
}

static void *
process3_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"\n********In Process %d**********\n",process3->p_pid);	

	dbg(DBG_INIT,"\nIn Process %d is trying to acquire the mutex1 lock...\n",process3->p_pid);	
	kmutex_lock(mutex1);
	dbg(DBG_INIT,"\nIn Process %d has acquired the mutex1 lock...\n",process3->p_pid);	

	sched_switch();	
	panic("This should not be printed:Deadlock is achieved");
	kmutex_lock(mutex2);
	
	kmutex_unlock(mutex2);

	kmutex_unlock(mutex1);

	return NULL;	
}

static void *
process4_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"\n********In Process %d**********\n",process4->p_pid);	
	dbg(DBG_INIT,"\nIn Process %d is trying to acquire the mutex2 lock...\n",process4->p_pid);	
	kmutex_lock(mutex2);
	dbg(DBG_INIT,"\nIn Process %d has acquired the mutex2 lock...\n",process4->p_pid);	
	sched_switch();	
	panic("This should not be printed:Deadlock is achieved");
	kmutex_lock(mutex1);
	
	kmutex_unlock(mutex1);
	kmutex_unlock(mutex2);
	return NULL;	
}


*/
/*===============================================TEST CASE 7=============================================*/
/*
static void *
initproc_run(int arg1, void *arg2)
{
	producer = proc_create("producer");
	kthread_t *thr_producer = kthread_create(producer, producer_routine, 0, (void *)0);
	sched_make_runnable(thr_producer);	

	consumer = proc_create("consumer");
	kthread_t *thr_consumer = kthread_create(consumer, consumer_routine, 0, (void *)0);
	sched_make_runnable(thr_consumer);

	sched_queue_init(&pro_con_q);	

	pid_t child;
	int status;
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	return NULL;	
}

static void *
producer_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT,"************Producer-Consumer Problem-Solution************\n");	
	dbg(DBG_INIT,"Buffer Size: 5 bytes\n");		
		
	int num_write = 7; int i = 0;	
	dbg(DBG_INIT,"Producer wants to write %d bytes\n", num_write);
	while(num_write>0)
	{
		if(empty>0)
		{
			a[nextin] = 1;
			nextin++;
			if(nextin==5)
				nextin=0;
			occupied++;
			empty--;
			num_write--;
			dbg(DBG_INIT,"Producer has written: %d bytes\n", (7-num_write));			
		}
		else
		{
			dbg(DBG_INIT,"Buffer is full, Producer is sleeping on...\n");
			if(!sched_queue_empty(&pro_con_q))
				sched_wakeup_on(&pro_con_q);
			sched_sleep_on(&pro_con_q);
		}
	}

	if(num_write==0)
	{		
		sched_wakeup_on(&pro_con_q);
		dbg(DBG_INIT,"Producer has written total of %d bytes\n", (7-num_write));
		dbg(DBG_INIT,"Producer is exiting...\n");
		kthread_exit((void *)1);
	}	

	return NULL;	
}

static void *
consumer_routine(int arg1, void *arg2)
{
	int num_read = 7; int i = 0;	
	dbg(DBG_INIT,"Consumer wants to read %d bytes\n", num_read);
	while(num_read>0)
	{
		if(occupied>0)
		{
			a[nextout] = 0;
			nextout++;
			if(nextout==5)
				nextout=0;
			empty++;
			occupied--;
			num_read--;
			dbg(DBG_INIT,"Consumer has read: %d bytes\n", (7-num_read));
		}
		else
		{
			dbg(DBG_INIT,"Buffer is empty, Consumer is sleeping on...\n");			
			sched_wakeup_on(&pro_con_q);
			sched_sleep_on(&pro_con_q);
		}
	}
	
	dbg(DBG_INIT,"Consumer has read total of %d bytes\n", (7-num_read));
	dbg(DBG_INIT,"Consumer is exiting...\n");
	kthread_exit((void *)1);
	return NULL;	
} 
*/


/*===============================================TEST CASE 8=============================================*/

/*
static void *
initproc_run(int arg1, void *arg2)
{	
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);	
	proc_t *process3 = proc_create("process3");
	kthread_t *thread3 = kthread_create(process3, process3_routine, 0, (void *)0);
	sched_make_runnable(thread3);	
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process3->p_pid);

	proc_t *process4 = proc_create("process4");
	kthread_t *thread4 = kthread_create(process4, process4_routine, 0, (void *)0);
	sched_make_runnable(thread4);
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process4->p_pid);
	
	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}

static void *
process3_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);
		
	proc_t *process5 = proc_create("process5");
	kthread_t *thread5 = kthread_create(process5, process5_routine, 0, (void *)0);
	sched_make_runnable(thread5);
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process5->p_pid);	

	proc_t *process6 = proc_create("process6");
	kthread_t *thread6 = kthread_create(process6, process6_routine, 0, (void *)0);
	sched_make_runnable(thread6);	
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process6->p_pid);
	
	pid_t child;
	int status;
	

	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;	
}

static void *
process4_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);		
	
	proc_t *process7 = proc_create("process7");
	kthread_t *thread7 = kthread_create(process7, process7_routine, 0, (void *)0);
	sched_make_runnable(thread7);	
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process7->p_pid);

	proc_t *process8 = proc_create("process8");
	kthread_t *thread8 = kthread_create(process8, process8_routine, 0, (void *)0);
	sched_make_runnable(thread8);	
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process8->p_pid);
	
	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;
}   

static void *
process5_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);

	proc_t *process9 = proc_create("process9");
	kthread_t *thread9 = kthread_create(process9, process9_routine, 0, (void *)0);
	sched_make_runnable(thread9);	
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process9->p_pid);

	proc_t *process10 = proc_create("process10");
	kthread_t *thread10 = kthread_create(process10, process10_routine, 0, (void *)0);
	sched_make_runnable(thread10);	
	dbg(DBG_INIT, "Process %d has created a process with pid %d!!!\n", curproc->p_pid, process10->p_pid);
	
	pid_t child;
	int status;
	
	while(!list_empty(&curproc->p_children))
	{
		child = do_waitpid(-1, 0, &status);
		dbg(DBG_INIT, "Process %d has been cleaned!!!\n", child);
	}	
	
	return NULL;
}  


static void *
process6_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);
	return NULL;
}


static void *
process7_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);
	dbg(DBG_INIT, "Process with pid %d exiting...\n", curproc->p_pid);
	
	kthread_exit((void *)1);
	panic("Error: This should not be printed!!!\n");
	
	return NULL;
}

static void *
process8_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);
	return NULL;
}

static void *
process9_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);
	return NULL;
}

static void *
process10_routine(int arg1, void *arg2)
{
	dbg(DBG_INIT, "Inside Process with pid %d\n", curproc->p_pid);
	return NULL;
}

*/

/**
 * Clears all interrupts and halts, meaning that we will never run
 * again.
 */
static void
hard_shutdown()
{
#ifdef __DRIVERS__
        vt_print_shutdown();
#endif
        __asm__ volatile("cli; hlt");
}
